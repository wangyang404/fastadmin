<?php

return [
    'Id'                   => '主键',
    'Stat_date'            => '日期',
    'User_id'              => '用户ID',
    'Username'             => '用户账号',
    'Ad_id'                => '广告ID',
    'Ad_name'              => '广告名称',
    'Plan_id'              => '计划ID',
    'Plan_name'            => '计划名称',
    'Pv_num'               => 'PV统计量',
    'Uv_num'               => 'UV统计量',
    'Ip_num'               => 'IP数 访问IP去重数量',
    'Click_num'            => '点击量 点击广告数量',
    'Click_ip_num'         => '点击IP量 点击广告的IP去重数量',
    'Ad_user_spend'        => '广告主消费',
    'Site_user_profit'     => '站长盈利',
    'Admin_user_profit'    => '管理员盈利',
    'Customer_user_profit' => '客服盈利',
    'Business_user_profit' => '商务盈利',
    'Create_time'          => '创建时间',
    'Update_time'          => '更新时间'
];
