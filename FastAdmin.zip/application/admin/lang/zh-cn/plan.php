<?php

return [
    'Id'                => '主键',
    'Plan_name'         => '计划名称',
    'User_id'           => '所属广告主ID',
    'Plan_type'         => '计划类型 ',
    'Cost_money'        => '已花费额度',
    'Total_money'       => '计划总额',
    'Plan_price'        => '计划单价',
    'Custom_user_price' => '用户分组/用户等级显示单价 {"group":{"groupId":0.1},"level":"level1":0.2}',
    'Order_num'         => '排序',
    'Is_effective'      => '状态',
    'Create_time'       => '创建时间',
    'Update_time'       => '更新时间',
    'Limit_money'       => '限额'
];
