<?php

return [
    'name'  => '变量名称',
    'intro' => '描述',
    'group' => '分组',
    'type'  => '类型',
    'value' => '变量值'
];
