<?php


namespace app\api\controller;


use app\common\controller\Api;
use think\Db;

class Stats extends Api
{
    protected $noNeedLogin = ['dayRevenue', 'mobilelogin', 'register', 'resetpwd', 'changeemail', 'changemobile', 'third'];
    protected $noNeedRight = '*';


    public function _initialize()
    {
        parent::_initialize();
    }

    public function dayRevenue()
    {
        $userinfo = $this->auth->getUserinfo();

        //今日收入
        $todayRevenue = Db::table('stat_ad_day')->whereTime('CREATE_TIME', 'today')->where('USER_ID',$userinfo['id'])->sum('SITE_USER_PROFIT');


        //账户余额 当天 + 未结算

        $remaining = Db::table('sys_user')->where('id',$userinfo['id'])->field('BALANCE') -> select();


        //查询统计表今日7天的收入 最近7天的PV

        $query = Db::table('stat_ad_day')->whereTime('CREATE_TIME', '>', '-7 days')->where('USER_ID',$userinfo['id'])->field('STAT_DATE,PV_NUM,SITE_USER_PROFIT')->select();

        $content = [
            'todayRevenue'    => $todayRevenue,
            'lastdayRevenue' => $remaining,
            'query'  =>$query,

        ];
        $this->success('', $content);


    }

}